package es.ed;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double radio = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
                System.out.print("Introduzca el radio de la circunferencia: ");
                radio = scanner.nextDouble();
                validInput = true;
            } catch (Exception e) {
                System.out.println("Error, introduzca un número válido.");
                scanner.nextLine();
            }
        }
        
        Circunferencia circunferencia = new Circunferencia(radio);

        double area = circunferencia.calcularArea();
        double perimetro = circunferencia.calcularPerimetro();

        System.out.println("El área de la circunferencia es: " + area);
        System.out.println("El perímetro de la circunferencia es: " + perimetro);
    }
}
