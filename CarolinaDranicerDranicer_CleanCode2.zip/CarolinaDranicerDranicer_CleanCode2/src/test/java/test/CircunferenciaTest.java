package test;

import es.ed.Circunferencia;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;


public class CircunferenciaTest {
    
    @Test
    @DisplayName("Area")
    public void testCalcularArea() {
        Circunferencia circunferencia = new Circunferencia(5);
        assertEquals(78.53981633974483, circunferencia.calcularArea(), 0.0000001);
    }

    @Test
    @DisplayName("Perimetro")
    public void testCalcularPerimetro() {
        Circunferencia circunferencia = new Circunferencia(5);
        assertEquals(31.41592653589793, circunferencia.calcularPerimetro(), 0.0000001);
    }

    @Test
    @DisplayName("RadioNegativo")
    public void testRadioNegativo() {
        try {
            Circunferencia circunferencia = new Circunferencia(-5);
        } catch (IllegalArgumentException e) {
            // Se espera que se lance la excepción.
        }
    }

    @Test
    @DisplayName("RadioCero")
    public void testRadioCero() {
        try {
            Circunferencia circunferencia = new Circunferencia(0);
        } catch (IllegalArgumentException e) {
            // Se espera que se lance la excepción.
        }
    }
        @BeforeAll
    public static void setUpAll() {
        System.out.println("Configuracion inicial para todas las pruebas");
    }

    @BeforeEach
    public void setUp() {
        System.out.println("Inicializacion antes de cada prueba");
    }

    @AfterEach
    public void tearDown() {
        System.out.println("Limpieza despues de cada prueba");
    }

    @AfterAll
    public static void tearDownAll() {
        System.out.println("Limpieza despues de todas las pruebas");
    }
}

